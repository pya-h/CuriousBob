* If this is your first run:
    > pip3 install -r requirements.txt

> python3 game.py